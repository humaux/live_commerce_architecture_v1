# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: live-console.spec.ts >> PARITY-LIVE current Figma route parity (MOCK) >> frame 1429:39683 D|normal|buyer|private|A|全部
- Location: tests/admin/live-console.spec.ts:911:41

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('heading', { name: '留言與私訊', exact: true })
Expected: visible
Timeout: 10000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByRole('heading', { name: '留言與私訊', exact: true }) with timeout 10000ms
  - waiting for getByRole('heading', { name: '留言與私訊', exact: true })

```

# Test source

```ts
  820  | ];
  821  | const parityIDs = {
  822  |   offer: "11111111-1111-4111-8111-111111111111",
  823  |   sku: "22222222-2222-4222-8222-222222222222",
  824  |   warehouse: "33333333-3333-4333-8333-333333333333",
  825  |   operation: "44444444-4444-4444-8444-444444444444",
  826  |   outbound: "55555555-5555-4555-8555-555555555555",
  827  | };
  828  | 
  829  | /** MOCK only: fixtures model upstream observations; clicks never change DOM or bypass the real route. */
  830  | async function parityFixture(page: Page, locale: ParityLocale, state = "selected", buyer = "A", context = "", dispatchFromClick = false) {
  831  |   const c = parityCopy[locale], at = "2026-10-30T00:00:00Z";
  832  |   let receipt = dispatchFromClick ? "" : state === "pending" ? "UNKNOWN" : state === "sent" ? "SUCCEEDED" : state === "blocked" ? "BLOCKED_POLICY" : "";
  833  |   let publicReplies = !dispatchFromClick && state === "publicSent" ? 1 : 0;
  834  |   let replyPosts = 0, paused = state === "paused" || context === "paused", off = state === "off" || context === "off";
  835  |   const sold = state === "sold" || context === "sold";
  836  |   const window = () => ({ session_id: comments.session, state: paused ? "CLOSED" : "OPEN", generation: 1, version: 1, match_mode: "KEYWORD_QTY_ONLY", opened_at: at, closed_at: paused ? at : null });
  837  |   const offer = (): Offer => ({ offer_id: parityIDs.offer, session_id: comments.session, keyword: "101", sku_id: parityIDs.sku, sku_code: "SKU-1042", product_name: c.product, max_quantity_per_claim: 5, active: !off, version: 1, activated_at: at, updated_at: at, sku_price_minor: 10000, currency: "TWD", live_price_minor: null });
  838  |   const snapshot = (): ConsoleSnapshot => ({
  839  |     session: { id: comments.session, title: c.session, lifecycle: "live", version: 1, started_at: at, ended_at: null },
  840  |     window: { state: paused ? "CLOSED" : "OPEN", generation: 1, opened_at: at, match_mode: "KEYWORD_QTY_ONLY" },
  841  |     stats: { comments: { total: 128, source: "graph_summary" }, keyword_comments: 36, buyers: 2, orders: { count: 12, amount_minor: 120000 }, paid: { count: 8, amount_minor: 80000 }, currency: "TWD", as_of: at },
  842  |     offers: [{ offer_id: parityIDs.offer, keyword: "101", sku_id: parityIDs.sku, product_name: c.product, variant_label: "SKU-1042", active: !off, version: 1, live_price_minor: null, sku_price_minor: 10000, stock: { tracked: true, sellable: sold ? 0 : 18, reserved: 2, warehouse_id: parityIDs.warehouse, balance_version: 1 }, claimed: { buyers: 1, quantity: 2 }, ordered_qty: 20, paid_qty: 20, paid_amount_minor: 200000, sold_out: sold, low_stock: false }],
  843  |     capabilities: { facebook: Object.fromEntries(["read_comment", "private_reply", "dm_session", "reply_public"].map(name => [name, { state: state === "restricted" && name === "private_reply" ? "missing_permission" : "ok", reason: "", evidence: "MOCK", checked_at: at }])) },
  844  |     stream: { state: "live", poll_interval_ms: 5000, last_ok_at: at, lag_ms: 0, source_platform: "facebook", video_embeddable: false }, recommended: null,
  845  |   });
  846  |   const rows = (): StreamComment[] => ["A", "B"].map((target, index) => ({
  847  |     ref: index ? comments.reply_refs[0]! : comments.claim_ref, seq: index + 1, parent_ref: null, created_at: at,
  848  |     author_name: `${c.buyer} ${target}`, text: index ? c.question : "101+2", is_page: false, has_attachment: false,
  849  |     marks: {
  850  |       intake: null,
  851  |       claim: index ? null : { status: "ACCEPTED", reason: null, offer_id: parityIDs.offer, keyword: "101", quantity: 2, bundle_id: comments.bundle },
  852  |       private_reply: target === buyer && receipt ? { kind: "manual", state: receipt, blocked_reason: state === "blocked" ? "window_closed" : null } : null,
  853  |       printed: null, public_replies: target === buyer ? publicReplies : 0,
  854  |       private_reply_available: !(target === buyer && (receipt || state === "expired")),
  855  |       ...(target === buyer && state === "expired" ? { private_reply_unavailable_reason: "expired_7d" } : {}),
  856  |     },
  857  |   }));
  858  |   // SETUP: intercept only synthetic, server-shaped console responses on this authenticated MOCK route.
  859  |   // Existing REAL_PG safety tests above remain intact and exercise the unmocked implementation.
  860  |   await page.route(`**/api/stores/${store}/**`, async intercepted => {
  861  |     const request = intercepted.request(), path = new URL(request.url()).pathname;
  862  |     const base = `/api/stores/${store}/live-sessions/${comments.session}`;
  863  |     const json = (value: unknown) => intercepted.fulfill({ status: 200, contentType: "application/json", body: JSON.stringify(value) });
  864  |     if (path === `${base}/console`) return json(snapshot());
  865  |     if (path === `${base}/claims` && request.method() === "GET") return json({ window: window(), offers: [offer()], stats: { generation: 1, accepted: 1, rejected: Object.fromEntries(["NO_MATCH", "UNKNOWN_KEYWORD", "OFFER_INACTIVE", "INVALID_QUANTITY", "QUANTITY_REQUIRED", "QUANTITY_OVER_MAX", "BUNDLE_LIMIT"].map(key => [key, 0])) } });
  866  |     if (path === `${base}/comments` && request.method() === "GET") return json({ epoch: 1, reset: false, scan_exhausted: false, items: rows(), next: { epoch: 1, seq: 2 }, older_cursor: null, stream: snapshot().stream });
  867  |     if (path === `/api/stores/${store}/inbox/buyer-panel`) {
  868  |       const data: BuyerData = { display_name: `${c.buyer} A`, platform: "facebook", purchase_ordinal: 0, claims: [{ session_id: comments.session, offer_id: parityIDs.offer, keyword: "101", quantity: 2 }], claim_total_minor: 20000, orders: [], linked_customer_id: null, window_open_until: null, link_pending_manual: false };
  869  |       return json(data);
  870  |     }
  871  |     if (path === `/api/stores/${store}/inbox/conversations`) return json({ items: [{ bundle_id: comments.bundle, session_id: comments.session, platform: "facebook", display_name: `${c.buyer} A`, last_at: at, unread: true, unreplied: true, mode: null, assignee: null, window_open_until: null, linked_customer_id: null }], next_cursor: "", unread_total: 1 });
  872  |     if (path === `${base}/claims/blocklist/check`) return json({ restricted: false });
  873  |     if (/\/comments\/[^/]+\/(private|public)-reply$/.test(path) && request.method() === "POST") {
  874  |       replyPosts++;
  875  |       const sendState = dispatchFromClick ? state === "pending" ? "unknown" : "sent" : "queued";
  876  |       if (path.endsWith("/private-reply")) receipt = sendState === "sent" ? "SUCCEEDED" : sendState === "unknown" ? "UNKNOWN" : "READY";
  877  |       else publicReplies++;
  878  |       return json({ send_state: sendState, operation_id: parityIDs.operation, outbound_id: parityIDs.outbound });
  879  |     }
  880  |     if (path === `${base}/claims/window` && request.method() === "POST") {
  881  |       paused = request.postDataJSON().state === "CLOSED";
  882  |       return json(window());
  883  |     }
  884  |     if (path === `${base}/claims/offers/${parityIDs.offer}` && request.method() === "PATCH") {
  885  |       off = !request.postDataJSON().active;
  886  |       return json(offer());
  887  |     }
  888  |     return intercepted.continue();
  889  |   });
  890  |   return { posts: () => replyPosts };
  891  | }
  892  | 
  893  | async function paritySelect(page: Page, locale: ParityLocale, buyer = "A") {
  894  |   await page.getByRole("button", { name: `${parityCopy[locale].buyer} ${buyer}`, exact: true }).click();
  895  | }
  896  | async function parityTab(page: Page, locale: ParityLocale, tab: string) {
  897  |   const c = parityCopy[locale];
  898  |   await page.getByRole("tab", { name: tab === "live" ? c.liveTab : tab === "comments" ? c.commentsTab : c.buyerTab, exact: true }).click();
  899  | }
  900  | async function parityShot(page: Page, id: string) {
  901  |   await mkdir(`${evidence}/parity`, { recursive: true });
  902  |   await page.screenshot({ path: `${evidence}/parity/${id}.png`, animations: "disabled" });
  903  | }
  904  | 
  905  | // The legacy test block is intentionally untouched. Each current signed state is selected by an actual click.
  906  | // Exact IDs let the independent reviewer compare the real route's artifact to the v3 DELIVERY export.
  907  | test.describe("PARITY-LIVE current Figma route parity (MOCK)", () => {
  908  |   test.afterEach(async ({}, info) => {
  909  |     await info.attach("click-ledger-outcome", { body: JSON.stringify({ page: "/[locale]/studio/console", test: info.title, expected: "signed copy, controls, buyer context and reply fencing", actual: info.status, result: info.status === "passed" ? "PASS in MOCK browser only" : "FAIL or NOT_RUN; inspect assertion failure", persistence: "explicit reload checks only; no buyer text stored" }), contentType: "application/json" });
  910  |   });
  911  |   for (const [id, key] of parityFrames) test(`frame ${id} ${key}`, async ({ page }, info) => {
  912  |     const [device, state, tab, channel, buyer, filter, context] = key.split("|");
  913  |     const locale = "zh-TW", c = parityCopy[locale];
  914  |     const dispatchFromClick = ["sent", "pending", "publicSent"].includes(state!);
  915  |     const mock = await parityFixture(page, locale, state, buyer, context, dispatchFromClick);
  916  |     await page.setViewportSize({ width: device === "D" ? 1440 : 390, height: device === "D" ? 900 : 844 });
  917  |     await login(page); await page.goto(route(locale, comments.session));
  918  |     // RED must fail here on the signed content, not during compilation, login or setup.
  919  |     if (device === "M") await parityTab(page, locale, "comments");
> 920  |     await expect(page.getByRole("heading", { name: c.stream, exact: true })).toBeVisible();
       |                                                                              ^ Error: expect(locator).toBeVisible() failed
  921  |     await expect(page.getByTestId("live-workspace")).not.toContainText("畫面顯示時每 5 秒更新");
  922  |     await expect(page.getByTestId("live-workspace")).not.toContainText(/\b(?:MOCK|UNKNOWN|queued)\b/);
  923  |     await expect(page.getByTestId("live-phase")).toHaveCount(0);
  924  |     if (state !== "normal") await paritySelect(page, locale, buyer);
  925  |     if (dispatchFromClick) {
  926  |       if (state === "publicSent") await page.getByTestId("comment-reply").getByRole("button", { name: c.public, exact: true }).click();
  927  |       await expect(page.getByRole("textbox", { name: c.reply, exact: true })).not.toHaveValue("");
  928  |       await page.getByRole("button", { name: state === "publicSent" ? c.publicSend : c.send, exact: true }).click();
  929  |       await expect.poll(mock.posts).toBe(1);
  930  |     }
  931  |     if (channel === "public") await page.getByTestId("comment-reply").getByRole("button", { name: c.public, exact: true }).click();
  932  |     if (filter !== "全部") {
  933  |       const control = page.getByTestId(`comment-filter-${filter === "關鍵字" ? "keyword" : filter === "私訊" ? "private" : "unreplied"}`);
  934  |       await expect(control).toHaveRole("button"); await expect(control).toHaveAccessibleName(filter!); await control.click();
  935  |     }
  936  |     if (device === "M") await parityTab(page, locale, tab!);
  937  |     const console = page.getByTestId("live-console");
  938  |     if (device === "D" || tab === "live") {
  939  |       await expect(console.getByRole("heading", { name: c.product, exact: true })).toBeVisible();
  940  |       await expect(console).toContainText("SKU-1042");
  941  |       if (state !== "sold" && context !== "sold") await expect(console.getByRole("button", { name: state === "off" || context === "off" ? c.on : c.off, exact: true })).toBeVisible();
  942  |     }
  943  |     if (state !== "normal") {
  944  |       const summary = page.getByTestId("live-reply-summary");
  945  |       await expect(summary).toBeVisible();
  946  |       await expect(summary).toContainText(`${c.buyer} ${buyer}`);
  947  |       await expect(summary).toContainText(buyer === "B" ? c.question : "101+2");
  948  |       if (buyer === "A") {
  949  |         await expect(summary).toContainText(c.product);
  950  |         await expect(summary).toContainText(c.registered);
  951  |         await expect(summary).toContainText(/2/);
  952  |         await expect(summary).toContainText(/5/);
  953  |         await expect(summary).toContainText(state === "sold" || context === "sold" ? /0/ : /18/);
  954  |         await expect(summary).toContainText(/20/);
  955  |       }
  956  |       const send = page.getByTestId("comment-reply").getByRole("button", { name: state === "pending" ? c.waitPending : ["sent", "blocked", "publicSent"].includes(state!) ? c.wait : channel === "public" ? c.publicSend : c.send, exact: true });
  957  |       if (["pending", "sent", "blocked", "publicSent"].includes(state)) await expect(send).toBeDisabled();
  958  |       if (state === "pending") await expect(console).toContainText(c.pending);
  959  |       if (state === "sent") await expect(console).toContainText(c.sent);
  960  |       if (state === "blocked") await expect(console).toContainText(c.blocked);
  961  |       if (state === "sold" || context === "sold") {
  962  |         await expect(page.getByRole("textbox", { name: c.reply, exact: true })).toHaveValue(c.sold);
  963  |         await expect(page.getByTestId("comment-reply").getByRole("button", { name: c.checkout, exact: true })).toHaveCount(0);
  964  |       }
  965  |     }
  966  |     // Read-only viewport measurement, never a DOM mutation or replacement for a user interaction.
  967  |     expect(await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth)).toBeLessThanOrEqual(1);
  968  |     expect(mock.posts()).toBe(dispatchFromClick ? 1 : 0);
  969  |     await parityShot(page, id);
  970  |     await info.attach("click-ledger", { body: JSON.stringify({ route: "/zh-TW/studio/console", frame: id, key, actions: [device === "M" ? "click Comments tab" : "open route", ...(state === "normal" ? [] : [`click Buyer ${buyer}`]), ...(channel === "public" ? ["click Public reply"] : []), ...(filter === "全部" ? [] : [`click ${filter}`]), ...(device === "M" ? [`click ${tab} tab`] : [])], result: "visible copy, summary, disabled controls and overflow asserted; screenshot captured", persistence: "read state reconstructed from MOCK upstream; draft persistence not claimed" }), contentType: "application/json" });
  971  |   });
  972  | 
  973  |   for (const locale of locales) for (const width of [1440, 390]) test(`main screen and controls ${locale} ${width}`, async ({ page }, info) => {
  974  |     const c = parityCopy[locale];
  975  |     const mock = await parityFixture(page, locale);
  976  |     await page.setViewportSize({ width, height: width === 390 ? 844 : 900 });
  977  |     await login(page); await page.goto(route(locale, comments.session));
  978  |     if (width === 390) await parityTab(page, locale, "comments");
  979  |     await expect(page.getByRole("heading", { name: c.stream, exact: true })).toBeVisible();
  980  |     await paritySelect(page, locale);
  981  |     if (width === 390) await parityTab(page, locale, "buyer");
  982  |     const reply = page.getByRole("textbox", { name: c.reply, exact: true });
  983  |     await reply.fill("Synthetic private draft A");
  984  |     await page.getByTestId("comment-reply").getByRole("button", { name: c.public, exact: true }).click();
  985  |     await reply.fill("Synthetic public draft A");
  986  |     await page.getByTestId("comment-reply").getByRole("button", { name: c.private, exact: true }).click();
  987  |     await expect(reply).toHaveValue("Synthetic private draft A");
  988  |     if (width === 390) await parityTab(page, locale, "comments");
  989  |     await paritySelect(page, locale, "B");
  990  |     if (width === 390) await parityTab(page, locale, "buyer");
  991  |     await expect(reply).not.toHaveValue("Synthetic private draft A");
  992  |     await reply.fill("Synthetic independent draft B");
  993  |     if (width === 390) await parityTab(page, locale, "comments");
  994  |     await paritySelect(page, locale);
  995  |     if (width === 390) await parityTab(page, locale, "buyer");
  996  |     await expect(reply).toHaveValue("Synthetic private draft A");
  997  |     await page.getByRole("button", { name: c.stock, exact: true }).click();
  998  |     await expect(reply).not.toHaveValue("Synthetic private draft A");
  999  |     await page.getByRole("button", { name: c.checkout, exact: true }).click();
  1000 |     await expect(reply).not.toHaveValue("");
  1001 |     // One real click dispatches to the MOCK network boundary; queued must not be displayed as delivered.
  1002 |     await page.getByRole("button", { name: c.send, exact: true }).click();
  1003 |     await expect.poll(mock.posts).toBe(1);
  1004 |     await expect(page.getByTestId("comment-send")).toBeDisabled();
  1005 |     await expect(page.getByTestId("live-console")).not.toContainText(c.sent);
  1006 |     await page.reload();
  1007 |     if (width === 390) await parityTab(page, locale, "comments");
  1008 |     await paritySelect(page, locale);
  1009 |     if (width === 390) await parityTab(page, locale, "buyer");
  1010 |     await expect(page.getByTestId("comment-send")).toBeDisabled();
  1011 |     expect(mock.posts()).toBe(1);
  1012 |     await parityShot(page, `main-${locale}-${width}`);
  1013 |     await info.attach("click-ledger", { body: "Buyer A → private/public drafts → Buyer B independent draft → restore A → stock quick reply → checkout quick reply → send once → reload → select A → send remains disabled; MOCK queued is not delivered", contentType: "text/plain" });
  1014 |   });
  1015 | 
  1016 |   for (const state of ["restricted", "expired", "pending"] as const) test(`${state} blocks send across refresh and context changes`, async ({ page }) => {
  1017 |     const c = parityCopy["zh-TW"], mock = await parityFixture(page, "zh-TW", state);
  1018 |     await login(page); await page.goto(route("zh-TW", comments.session));
  1019 |     await expect(page.getByRole("heading", { name: c.stream, exact: true })).toBeVisible();
  1020 |     await paritySelect(page, "zh-TW");
```