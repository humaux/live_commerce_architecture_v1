# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: live-settings.spec.ts >> manual reminders template and restriction real clicks en-1440
- Location: tests/admin/live-settings.spec.ts:102:3

# Error details

```
Error: expect(locator).toBeAttached() failed

Locator: getByTestId('live-console').getByRole('tab').first()
Expected: attached
Timeout: 10000ms
Error: element(s) not found

Call log:
  - Expect "toBeAttached" getByTestId('live-console').getByRole('tab').first() with timeout 10000ms
  - waiting for getByTestId('live-console').getByRole('tab').first()

```

# Test source

```ts
  1  | // Purpose: Reach signed console tabs and disclosures through the same real clicks in dependent browser suites.
  2  | // Depends on: Playwright locators and LiveConsole/CommentStream's existing tab/disclosure markup.
  3  | // Used by: live-console.spec.ts and live-settings.spec.ts; no fixture or response substitution.
  4  | // Invariants: disclosure identities stay stable as open state changes; never mutate DOM or bypass actionability.
  5  | import { expect, type Page } from "@playwright/test";
  6  | 
  7  | export async function showLivePanel(page: Page, panel: "live" | "comments" | "buyer") {
  8  |   const tabs = page.getByTestId("live-console").getByRole("tab");
> 9  |   await expect(tabs.first()).toBeAttached();
     |                              ^ Error: expect(locator).toBeAttached() failed
  10 |   if (await tabs.first().isVisible()) {
  11 |     const tab = tabs.nth(panel === "live" ? 0 : panel === "comments" ? 1 : 2);
  12 |     await tab.click();
  13 |     await expect(tab).toHaveAttribute("aria-selected", "true");
  14 |   }
  15 | }
  16 | 
  17 | export async function showLiveBuyerDetails(page: Page) {
  18 |   await showLivePanel(page, "buyer");
  19 |   const details = page.locator("[data-live-buyer-details]");
  20 |   await expect(details.locator(":scope > summary")).toBeVisible();
  21 |   if (await details.getAttribute("open") === null) await details.locator(":scope > summary").click();
  22 |   await expect(page.getByTestId("buyer-panel")).toBeVisible();
  23 | }
  24 | 
  25 | export async function showLiveTools(page: Page) {
  26 |   await showLivePanel(page, "live");
  27 |   // Index the stable disclosures, never :not([open]): clicking removes a match from that filtered list.
  28 |   const tools = page.locator("[data-live-tools]");
  29 |   await expect(tools.first()).toBeAttached();
  30 |   for (let index = 0; index < await tools.count(); index++) {
  31 |     const details = tools.nth(index);
  32 |     if (await details.getAttribute("open") === null) await details.locator(":scope > summary").click();
  33 |     await expect(details).toHaveAttribute("open", "");
  34 |   }
  35 | }
  36 | 
```