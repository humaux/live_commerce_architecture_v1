// Purpose: accept the owner-signed simplified customer journeys with real clicks in three locales.
// Depends on: Playwright, node:fs/promises, node:path; the existing CB11 signed-identity browser fixture.
// Used by: tests/foundation/browser_customers_billing_test.go, --browser-customers-billing in GitHub CI.
// Invariants: MOCK responses retain the existing DTO; no API/contract changes, DOM writes, force clicks or live data.
import { expect, test, type Page } from "@playwright/test";
import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";

const required = (name: string) => {
  const value = process.env[name];
  if (!value) throw new Error(`${name} required`);
  return value;
};
const origin = required("LC_BROWSER_PUBLIC_ORIGIN");
const store = required("LC_BROWSER_STORE");
const customer = required("LC_BROWSER_CUSTOMER");
const evidence = required("LC_BROWSER_EVIDENCE");
const name = "示範林一"; // Synthetic signed-frame fixture, never a real buyer.
const copy = {
  "zh-TW": { title: "顧客", search: "姓名開頭／電話末碼", submit: "搜尋", clear: "清除搜尋", view: "查看顧客", back: "返回搜尋結果", orders: "訂單", consent: "同意", privacy: "隱私", download: "下載顧客資料", confirmDownload: "確認下載", erase: "抹除顧客", confirmErase: "確認抹除", checked: "已核對處理與保留範圍", verify: "先核實身分", protected: "收件資料受保護；最多200筆訂單，妥善保管", permissions: "需隱私及顧客／訂單讀取權限", pending: "查看待處理要求", pendingBack: "返回待處理要求", viewData: "查看顧客資料", exportSubmitted: "下載要求已送出", eraseSubmitted: "抹除要求已送出" },
  "zh-CN": { title: "客户", search: "姓名开头／手机号尾号", submit: "搜索", clear: "清空搜索", view: "查看客户", back: "返回搜索结果", orders: "订单", consent: "授权记录", privacy: "隐私", download: "下载客户资料", confirmDownload: "确认下载", erase: "清除客户资料", confirmErase: "确认清除", checked: "已核对清除与保留范围", verify: "先核实申请人身份", protected: "收件信息受保护；最多200笔订单，请妥善保管", permissions: "需要隐私操作及客户／订单查看权限", pending: "查看待处理申请", pendingBack: "返回待处理申请", viewData: "查看客户资料", exportSubmitted: "下载申请已提交", eraseSubmitted: "资料清除申请已提交" },
  en: { title: "Customers", search: "Name prefix / last phone digits", submit: "Search", clear: "Clear search", view: "View customer", back: "Back to results", orders: "Orders", consent: "Consent", privacy: "Privacy", download: "Download customer data", confirmDownload: "Confirm download", erase: "Erase customer data", confirmErase: "Confirm erasure", checked: "I checked what will change and what will be kept", verify: "Verify the requester's identity first", protected: "Protected delivery details; up to 200 orders. Keep the file secure", permissions: "Requires privacy and customer/order read permissions", pending: "View pending request", pendingBack: "Back to pending request", viewData: "View customer data", exportSubmitted: "Download request submitted", eraseSubmitted: "Erasure request submitted" },
} as const; // Expectations transcribed from signed DELIVERY; never imported from implementation copy.
type Locale = keyof typeof copy;
type Ledger = { page: string; control: string; operation: string; expected: string; actual: string; result: "pass" | "fail" }[];
const ledgers = new WeakMap<Page, Ledger>();
const densities = new WeakMap<Page, { step: string; blocks: number; characters: number; width: number }[]>();
test.afterEach(async ({ page }, info) => {
  const stem = `people-v2-${info.title.replace(/[^a-zA-Z0-9-]/g, "-")}`;
  await writeFile(path.join(evidence, `${stem}-clicks.json`), JSON.stringify(ledgers.get(page) ?? [], null, 2));
  await writeFile(path.join(evidence, `${stem}-density.json`), JSON.stringify(densities.get(page) ?? [], null, 2));
});
async function act(page: Page, control: string, expected: string, action: () => Promise<unknown>, verify: () => Promise<unknown>, operation = "click") {
  const ledger = ledgers.get(page) ?? [];
  ledgers.set(page, ledger);
  const row: Ledger[number] = { page: new URL(page.url()).pathname, control, operation, expected, actual: "", result: "fail" };
  ledger.push(row);
  await test.step(`${control}: ${expected}`, async () => {
    try {
      await action(); await verify(); row.result = "pass"; row.actual = expected;
      // READ/MEASURE only. Native text blocks are recorded for independent density review, not DOM mutation or a claimed Figma probe result.
      const density = await page.evaluate(() => {
        const root = document.querySelector('dialog[open]') ?? document.querySelector('[data-testid="customer-detail"], [data-testid="customers-page"]');
        if (!root) return null;
        const candidates = [...root.querySelectorAll('h1,h2,h3,p,td,li,button,a,summary,label')].filter((node) => {
          const element = node as HTMLElement, style = getComputedStyle(element), rect = element.getBoundingClientRect();
          if (!element.innerText.trim() || rect.width <= 1 || rect.height <= 1 || style.visibility === "hidden" || style.display === "none") return false;
          for (let ancestor: Element | null = element; ancestor && ancestor !== root; ancestor = ancestor.parentElement) {
            if (ancestor instanceof HTMLDetailsElement && !ancestor.open && !ancestor.querySelector(':scope > summary')?.contains(element)) return false;
          }
          return true;
        });
        const blocks = candidates.filter((node) => !candidates.some((other) => other !== node && other.contains(node)));
        return { blocks: blocks.length, characters: blocks.reduce((n, node) => n + (node as HTMLElement).innerText.trim().length, 0), width: innerWidth };
      });
      if (density) { const rows = densities.get(page) ?? []; rows.push({ step: expected, ...density }); densities.set(page, rows); }
    }
    catch (error) { row.actual = error instanceof Error ? error.message : String(error); throw error; }
  });
}
async function signed(page: Page, width: number) {
  await page.setViewportSize({ width, height: width === 390 ? 844 : 900 });
  await page.goto(`${origin}/en/`);
  await act(page, "Sign in with identity service", "signed merchant workspace opens", () => page.getByRole("button", { name: "Sign in with identity service" }).click(), () => expect(page.getByTestId("shell-store-selector")).toBeVisible());
}

async function fixture(page: Page, fault: "none" | "export" | "erase" | "blocked" | "limit" | "read-export" | "read-erase" | "erase-success" | "forbidden" = "none", consentState?: "never" | "withdrawn" | "granted") {
  // MOCK fixture/fault preparation only. Actual privacy requests below originate solely from UI clicks.
  const row = {
    customer_id: customer, first_seen_at: "2026-09-12T00:00:00Z", last_activity_at: "2026-10-25T00:00:00Z",
    display_name: name, phone_last3: "805", orders_count: 3, paid_orders_count: 3,
    captured_minor: 384000, refunded_minor: 0, currency: "TWD", claims_count: 0,
    platforms: ["facebook"], consents: { marketing_messages: false, ads_personalization: true },
    active: true, imported: false, tags: [],
  };
  const orders = ["11111111-1111-4111-8111-111111111111", "22222222-2222-4222-8222-222222222222", "33333333-3333-4333-8333-333333333333"].map((id) => ({
    order_id: id, created_at: "2026-10-25T00:00:00.000000Z", updated_at: "2026-10-25T00:00:00.000000Z",
    currency: "TWD", total_minor: 128000, commercial_state: "CONFIRMED", fulfillment_state: "MANUAL_UNASSIGNED",
    payment_state: "CAPTURED", test_mode: true, work_state: "READY", refunded_minor: 0, refund_pending_minor: 0,
    pickup_source: null, payment_mode: "card", collection_state: null, cod_surcharge_minor: null, cod_collect_minor: null,
  }));
  const detail = {
    ...row, orders, claims: [], tags_revision: "a".repeat(64), notes: [],
    consent_history: [
      { purpose: "marketing_messages", channel: "meta_dm", granted: false, source: "buyer_settings", policy_version: "lc-2026-10", occurred_at: "2026-10-20T00:00:00Z" },
      { purpose: "ads_personalization", channel: "meta_ads", granted: true, source: "buyer_settings", policy_version: "lc-2026-10", occurred_at: "2026-10-01T00:00:00Z" },
    ],
    privacy_actions: [] as { kind: string; via: string; completed_at: string; summary: Record<string, number> | null }[],
  };
  if (consentState) {
    // New additive read DTO fixture; boolean false is never sufficient to invent a withdrawal.
    row.consents.marketing_messages = consentState === 'granted';
    detail.consents.marketing_messages = consentState === 'granted';
    Object.assign(row, { consent_state: { marketing_messages: consentState, ads_personalization: 'granted' } });
    Object.assign(detail, { consent_state: { marketing_messages: consentState, ads_personalization: 'granted' } });
    detail.consent_history = detail.consent_history.filter(event => event.purpose !== 'marketing_messages');
    if (consentState !== 'never') detail.consent_history.push({ purpose: 'marketing_messages', channel: 'meta_dm', granted: consentState === 'granted', source: 'buyer_settings', policy_version: 'lc-2026-10', occurred_at: '2026-10-20T00:00:00Z' });
  }
  const posts: { resource: string; key: string | undefined; body: string | null }[] = [];
  let detailReads = 0;
  await page.route(`**/api/stores/${store}/customers**`, async (route) => {
    const request = route.request(), url = new URL(request.url());
    const resource = url.pathname.split(`/customers`)[1];
    const json = (value: unknown, status = 200) => route.fulfill({ status, contentType: "application/json", headers: { "Cache-Control": "no-store" }, body: JSON.stringify(value) });
    if (request.method() === "GET") {
      if (resource === "/tags") return json({ items: [] });
      if (resource === "") {
        const q = url.searchParams.get("q") ?? "";
        return json({ items: !q || name.startsWith(q) || "805".endsWith(q) ? [row] : [], next_cursor: "" });
      }
      if (resource === `/${customer}`) {
        detailReads++;
        if (posts.length && fault.startsWith('read-')) return json({ code: 'unavailable' }, 503);
        return json(detail);
      }
      return route.continue();
    }
    posts.push({ resource, key: request.headers()["idempotency-key"], body: request.postData() });
    if (((fault === "export" || fault === "read-export") && resource.endsWith("/exports")) || ((fault === "erase" || fault === "read-erase") && resource.endsWith("/erasure"))) return route.abort("failed");
    if (fault === "forbidden") return json({ code: "forbidden" }, 403);
    if (fault === "limit" && resource.endsWith("/exports")) return json({ code: "export_too_large" }, 409);
    if (fault === "blocked" && resource.endsWith("/erasure")) return json({ code: "erasure_blocked" }, 409);
    if (resource.endsWith("/exports")) {
      detail.privacy_actions.push({ kind: "EXPORT", via: "merchant", completed_at: "2026-10-29T00:00:00Z", summary: null });
      return json({ schema: "lc.customer-export.v1", customer: row, orders, consent_history: detail.consent_history });
    }
    if (resource.endsWith("/erasure")) {
      detail.active = false; detail.consents = { marketing_messages: false, ads_personalization: false };
      const summary = { consents_withdrawn: 1, sessions_revoked: 1, snapshots_redacted: 0, bundles_relabelled: 0 };
      detail.privacy_actions.push({ kind: "ERASURE", via: "merchant", completed_at: "2026-10-29T00:00:00Z", summary });
      return json(summary);
    }
    return route.continue();
  });
  return { detail, posts, get detailReads() { return detailReads; } };
}
const mainURL = (locale: Locale) => `${origin}/${locale}/customers?store=${store}`;
const detailURL = (locale: Locale) => `${origin}/${locale}/customers/${customer}?store=${store}`;
async function fits(page: Page) {
  // READ/MEASURE only; no DOM or application state changes.
  expect(await page.evaluate(() => document.documentElement.scrollWidth - innerWidth)).toBeLessThanOrEqual(1);
}
async function eraseReady(page: Page) {
  await act(page, "Erase customer data", "signed erasure confirmation opens", () => page.getByTestId("customer-erase").click(), () => expect(page.getByTestId("erase-dialog")).toBeVisible());
  const dialog = page.getByTestId("erase-dialog"), submit = page.getByTestId("erase-submit");
  await expect(submit, "PEOPLE-V2-ERASE-NAME-AND-CHECK: empty confirmation is disabled").toBeDisabled();
  await act(page, "Customer name", "wrong customer name keeps erasure disabled", () => page.getByTestId("erase-typed").fill("other customer"), () => expect(submit).toBeDisabled(), "fill");
  await act(page, "Customer name", "correct name alone does not authorize erasure", () => page.getByTestId("erase-typed").fill(name), () => expect(submit).toBeDisabled(), "fill");
  const scope = dialog.getByRole("checkbox", { name: copy.en.checked, exact: true });
  await expect(scope, "PEOPLE-V2-ERASE-SCOPE: signed confirmation requires an explicit scope checkbox").toBeVisible();
  await act(page, copy.en.checked, "correct name and checked scope enable confirmation", () => scope.check(), () => expect(submit).toBeEnabled(), "check");
  await act(page, copy.en.checked, "unchecking scope disables erasure again", () => scope.uncheck(), () => expect(submit).toBeDisabled(), "uncheck");
  await act(page, copy.en.checked, "checking scope restores the ready state", () => scope.check(), () => expect(submit).toBeEnabled(), "check");
  await expect(dialog).toContainText("Withdraw consent, sign out devices and deactivate the customer.");
  await expect(dialog).toContainText("Handle social data separately.");
  await expect(dialog).toContainText("Completed erasure cannot be undone.");
}

for (const locale of ["zh-TW", "zh-CN", "en"] as const) for (const width of [1440, 390]) {
  test(`PEOPLE-V2 signed main path ${locale}-${width}`, async ({ page }) => {
    const c = copy[locale];
    await signed(page, width); await fixture(page); await page.goto(mainURL(locale));
    await expect(page.getByTestId(`customer-open-${customer}`)).toBeVisible(); // Existing baseline reaches new assertion.
    await expect(page.getByTestId("customers-search"), "PEOPLE-V2-SIGNED-SEARCH: signed concise search prompt").toHaveAttribute("placeholder", c.search);
    await expect(page.getByRole("heading", { level: 1 })).toHaveText(c.title);
    await fits(page);
    await act(page, c.search, "customer search draft is visible", () => page.getByTestId("customers-search").fill("示範林"), () => expect(page.getByTestId("customers-search")).toHaveValue("示範林"), "fill");
    await act(page, c.submit, "search results retain the customer and query", () => page.getByTestId("customers-search-submit").click(), async () => { await expect(page).toHaveURL(/q=/); await expect(page.getByTestId(`customer-open-${customer}`)).toContainText(name); });
    await act(page, "Refresh", "search persists after reload", () => page.reload(), () => expect(page.getByTestId("customers-search")).toHaveValue("示範林"), "reload");
    await act(page, c.view, "customer profile opens", () => page.getByTestId(`customer-open-${customer}`).click(), () => expect(page.getByTestId("customer-detail")).toContainText(name));
    await expect(page.getByTestId("customer-detail")).toContainText("805");
    await expect(page.getByTestId("customer-detail")).toContainText(customer.slice(0, 8));
    await expect(page.getByTestId("customer-detail")).toContainText(/3,840/);
    await expect(page.getByTestId("customer-detail")).toContainText("2026-09-12");
    await act(page, c.orders, "three server orders are visible", () => page.getByRole("link", { name: c.orders, exact: true }).click(), () => expect(page.getByTestId("customer-orders").locator("tbody tr")).toHaveCount(3));
    await act(page, c.consent, "consent facts remain visible", () => page.getByRole("link", { name: c.consent, exact: true }).click(), () => expect(page.getByTestId("customer-consent")).toContainText("2026-10-20"));
    await act(page, c.privacy, "privacy section opens", () => page.getByRole("link", { name: c.privacy, exact: true }).click(), () => expect(page.getByTestId("customer-download")).toHaveText(c.download));
    await fits(page);
    await act(page, c.back, "return preserves search context", () => page.getByRole("link", { name: c.back, exact: true }).click(), () => expect(page.getByTestId("customers-search")).toHaveValue("示範林"));
    await act(page, c.clear, "clear restores all store customers", () => page.getByRole("button", { name: c.clear, exact: true }).click(), () => expect(page.getByTestId("customers-search")).toHaveValue(""));
    await act(page, c.search, "phone suffix is accepted", () => page.getByTestId("customers-search").fill("805"), () => expect(page.getByTestId("customers-search")).toHaveValue("805"), "fill");
    await act(page, c.submit, "phone search returns the matching customer", () => page.getByTestId("customers-search-submit").click(), () => expect(page.getByTestId(`customer-open-${customer}`)).toContainText(name));
  });
}

for (const width of [1440, 390]) {
  test(`PEOPLE-V2 export confirmation and persistence en-${width}`, async ({ page }) => {
    await signed(page, width); const f = await fixture(page); await page.goto(detailURL("en"));
    await expect(page.getByTestId("customer-download")).toBeVisible();
    await act(page, "Download data", "PEOPLE-V2-EXPORT-CONFIRM: review opens before any POST", () => page.getByTestId("customer-download").click(), () => expect(page.getByRole("button", { name: copy.en.confirmDownload, exact: true })).toBeVisible());
    expect(f.posts).toHaveLength(0);
    for (const fact of [name, "805", copy.en.verify, copy.en.protected, copy.en.permissions]) await expect(page.getByTestId("customer-detail")).toContainText(fact);
    const download = page.waitForEvent("download");
    await act(page, copy.en.confirmDownload, "synchronous export delivers one file", () => page.getByRole("button", { name: copy.en.confirmDownload, exact: true }).click(), async () => { expect((await download).suggestedFilename()).toMatch(/\.json$/); expect(f.posts).toHaveLength(1); });
    await act(page, "Refresh", "completed export remains in server history", () => page.reload(), () => expect(page.getByTestId("privacy-actions")).toContainText("Data export"), "reload");
    await act(page, "Advanced", "completed server history becomes visible", () => page.getByTestId("people-customer-tools").locator(":scope > summary").click(), () => expect(page.getByTestId("privacy-actions")).toBeVisible());
    expect(f.posts).toHaveLength(1); expect(f.posts[0].key).toBeTruthy(); await fits(page);
  });
  test(`PEOPLE-V2 erasure name checkbox and persistence en-${width}`, async ({ page }) => {
    await signed(page, width); const f = await fixture(page); await page.goto(detailURL("en"));
    await expect(page.getByTestId("customer-erase")).toBeVisible(); await eraseReady(page);
    expect(f.posts).toHaveLength(0);
    await act(page, copy.en.confirmErase, "erasure success reflects server deactivation", () => page.getByTestId("erase-submit").click(), () => expect(page.getByTestId("customer-erased")).toBeVisible());
    expect(f.posts).toHaveLength(1); expect(f.posts[0].body).toBe(JSON.stringify({ confirm: "ERASE" }));
    await act(page, "Refresh", "server erasure and retained orders survive reload", () => page.reload(), async () => { await expect(page.getByTestId("customer-erased")).toBeVisible(); await expect(page.getByTestId("customer-orders").locator("tbody tr")).toHaveCount(3); }, "reload");
    expect(f.posts).toHaveLength(1); await fits(page);
  });
  test(`PEOPLE-V2 blocked erasure retains customer and orders en-${width}`, async ({ page }) => {
    await signed(page, width); const f = await fixture(page, "blocked"); await page.goto(detailURL("en"));
    await expect(page.getByTestId("customer-erase")).toBeVisible(); await eraseReady(page);
    await act(page, copy.en.confirmErase, "server refusal is visible without claiming erasure", () => page.getByTestId("erase-submit").click(), () => expect(page.getByTestId("erase-problem")).toContainText(/payment|order|refund/i));
    expect(f.posts).toHaveLength(1); expect(f.detail.active).toBe(true);
    await expect(page.getByTestId("customer-erased")).toHaveCount(0);
    await act(page, "Refresh", "refused erasure keeps all three server orders", () => page.reload(), async () => { await expect(page.getByTestId("customer-orders").locator("tbody tr")).toHaveCount(3); await expect(page.getByTestId("customer-erased")).toHaveCount(0); }, "reload");
    expect(f.posts).toHaveLength(1);
  });
  for (const kind of ["export", "erase"] as const) {
    test(`PEOPLE-V2 ${kind} uncertain read-only return en-${width}`, async ({ page }) => {
      await signed(page, width); const f = await fixture(page, kind); await page.goto(detailURL("en"));
      if (kind === "erase") { await expect(page.getByTestId("customer-erase")).toBeVisible(); await eraseReady(page); }
      else {
        await expect(page.getByTestId("customer-download")).toBeVisible();
        await act(page, copy.en.download, "PEOPLE-V2-EXPORT-CONFIRM: opens confirmation", () => page.getByTestId("customer-download").click(), () => expect(page.getByRole("button", { name: copy.en.confirmDownload, exact: true })).toBeVisible());
      }
      await act(page, kind === "erase" ? copy.en.confirmErase : copy.en.confirmDownload, "unconfirmed result offers only the signed read-only path", () => kind === "erase" ? page.getByTestId("erase-submit").click() : page.getByRole("button", { name: copy.en.confirmDownload, exact: true }).click(), () => expect(page.getByRole("button", { name: copy.en.pending, exact: true })).toBeVisible());
      expect(f.posts).toHaveLength(1);
      await act(page, copy.en.pending, "existing unconfirmed request entry is visible", () => page.getByRole("button", { name: copy.en.pending, exact: true }).click(), () => expect(page.getByRole("button", { name: copy.en.viewData, exact: true })).toBeVisible());
      await act(page, copy.en.viewData, "customer stays readable with both privacy commands locked", () => page.getByRole("button", { name: copy.en.viewData, exact: true }).click(), async () => { await expect(page.getByTestId("customer-download")).toBeDisabled(); await expect(page.getByTestId("customer-erase")).toBeDisabled(); });
      await act(page, "Refresh", "unconfirmed request is not silently replayed or unlocked", () => page.reload(), async () => { await expect(page.getByTestId("customer-download")).toBeDisabled(); await expect(page.getByTestId("customer-erase")).toBeDisabled(); }, "reload");
      expect(f.posts).toHaveLength(1);
      await act(page, copy.en.pendingBack, "read-only return preserves customer identity", () => page.getByRole("button", { name: copy.en.pendingBack, exact: true }).click(), () => expect(page.getByTestId("customer-detail")).toContainText(name));
      expect(f.posts).toHaveLength(1); await fits(page);
    });
  }
  // Reach the shared uncertainty fence independently of the negative name/checkbox assertions above.
  // These positive preparations still use real controls and the same closed DTO/fault fixture.
  for (const reload of [false, true]) {
    test(`PEOPLE-V2 independent uncertainty fence ${reload ? "reload" : "return"} en-${width}`, async ({ page }) => {
      await signed(page, width); const f = await fixture(page, "erase"); await page.goto(detailURL("en"));
      await expect(page.getByTestId("customer-erase")).toBeEnabled();
      await act(page, copy.en.erase, "erasure review opens", () => page.getByTestId("customer-erase").click(), () => expect(page.getByTestId("erase-dialog")).toBeVisible());
      await act(page, name, "exact customer name is visible", () => page.getByTestId("erase-typed").fill(name), () => expect(page.getByTestId("erase-typed")).toHaveValue(name), "fill");
      await act(page, copy.en.checked, "scope is explicitly acknowledged", () => page.getByRole("checkbox", { name: copy.en.checked, exact: true }).check(), () => expect(page.getByTestId("erase-submit")).toBeEnabled(), "check");
      expect(f.posts).toHaveLength(0);
      await act(page, copy.en.confirmErase, "lost response reaches the unconfirmed result", () => page.getByTestId("erase-submit").click(), () => expect(page.getByRole("button", { name: copy.en.pending, exact: true })).toBeVisible());
      expect(f.posts).toHaveLength(1);
      await act(page, copy.en.pending, "pending entry offers the read-only customer view", () => page.getByRole("button", { name: copy.en.pending, exact: true }).click(), () => expect(page.getByRole("button", { name: copy.en.viewData, exact: true })).toBeVisible());
      await act(page, copy.en.viewData, "customer profile remains readable", () => page.getByRole("button", { name: copy.en.viewData, exact: true }).click(), () => expect(page.getByTestId("customer-detail")).toContainText(name));
      if (reload) await act(page, "Refresh", "server customer remains readable after reload", () => page.reload(), () => expect(page.getByTestId("customer-detail")).toContainText(name), "reload");
      await expect(page.getByTestId("customer-download"), `PEOPLE-V2-UNKNOWN-FENCE-${reload ? "RELOAD" : "RETURN"}: export stays locked`).toBeDisabled();
      await expect(page.getByTestId("customer-erase"), `PEOPLE-V2-UNKNOWN-FENCE-${reload ? "RELOAD" : "RETURN"}: erasure stays locked`).toBeDisabled();
      expect(f.posts).toHaveLength(1);
      await fits(page);
    });
  }
}


// PARITY: independent signed-control assertions and full frame captures on the real routed pages.
const parityCopy = {
  'zh-TW': { advanced: '進階', marketing: '行銷訊息：已撤回', downloaded: '資料已下載', erased: '顧客已抹除', limit: '資料超出下載上限', blocked: '目前無法抹除', back: '返回顧客資料' },
  'zh-CN': { advanced: '高级', marketing: '营销消息：已撤回授权', downloaded: '资料已下载', erased: '客户资料已清除', limit: '资料超出下载上限', blocked: '目前无法清除', back: '返回客户资料' },
  en: { advanced: 'Advanced', marketing: 'Marketing messages: Consent withdrawn', downloaded: 'Data downloaded', erased: 'Customer erased', limit: 'Download limit exceeded', blocked: 'Cannot erase right now', back: 'Back to customer' },
} as const;
async function parity(page: Page, desktop: string, mobile: string) {
  const frame = `1429-${page.viewportSize()?.width === 390 ? mobile : desktop}`;
  const dir = test.info().outputPath('parity'); await mkdir(dir, { recursive: true });
  const file = path.join(dir, `${frame}.png`); await page.screenshot({ path: file });
  await test.info().attach(`parity/${frame}`, { path: file, contentType: 'image/png' });
}
for (const locale of ['zh-TW', 'zh-CN', 'en'] as const) for (const width of [1440, 390]) {
  test(`PARITY people signed controls ${locale}-${width}`, async ({ page }) => {
    const c = copy[locale], p = parityCopy[locale];
    await signed(page, width); await fixture(page); await page.goto(mainURL(locale));
    await expect(page.getByTestId(`customer-open-${customer}`)).toBeVisible();
    await expect(page.getByRole('button', { name: c.submit, exact: true })).toBeVisible();
    await expect(page.locator('summary', { hasText: p.advanced }), 'PARITY-PEOPLE: unsigned list disclosure removed').toHaveCount(0);
    await parity(page, '44136', '44240');
    await act(page, c.search, 'signed search input is editable', () => page.getByTestId('customers-search').fill('示範林'), () => expect(page.getByTestId('customers-search')).toHaveValue('示範林'), 'fill');
    await act(page, c.submit, 'signed search results', () => page.getByRole('button', { name: c.submit, exact: true }).click(), () => expect(page.getByTestId(`customer-open-${customer}`)).toBeVisible());
    await parity(page, '44287', '44349');
    await act(page, c.view, 'signed profile opens', () => page.getByTestId(`customer-open-${customer}`).click(), () => expect(page.getByTestId('customer-consent')).toBeVisible());
    await expect(page.locator('summary', { hasText: p.advanced }), 'PARITY-PEOPLE: unsigned detail disclosure removed').toHaveCount(0);
    await parity(page, '44396', '44485');
    await act(page, c.download, 'download review opens before POST', () => page.getByRole('button', { name: c.download, exact: true }).click(), () => expect(page.getByRole('button', { name: c.confirmDownload, exact: true })).toBeVisible());
    await parity(page, '44734', '44772');
    await page.getByRole('button', { name: p.back, exact: true }).click();
    await act(page, c.erase, 'erasure review opens', () => page.getByRole('button', { name: c.erase, exact: true }).click(), () => expect(page.getByTestId('erase-typed')).toBeVisible());
    await parity(page, '45148', '45193');
    await page.getByTestId('erase-typed').fill(name);
    await page.getByRole('checkbox', { name: c.checked, exact: true }).check();
    await expect(page.getByRole('button', { name: c.confirmErase, exact: true })).toBeEnabled();
    await parity(page, '45229', '45272');
  });
  for (const fault of ['none', 'limit', 'blocked', 'read-export', 'read-erase', 'erase-success'] as const) {
    test(`PARITY people privacy ${fault} ${locale}-${width}`, async ({ page }) => {
      const c = copy[locale], p = parityCopy[locale];
      await signed(page, width); const f = await fixture(page, fault); await page.goto(detailURL(locale));
      const erase = fault === 'blocked' || fault === 'read-erase' || fault === 'erase-success';
      await expect(page.getByTestId(erase ? 'customer-erase' : 'customer-download')).toBeEnabled();
      if (erase) {
        await page.getByTestId('customer-erase').click();
        await page.getByTestId('erase-typed').fill(name);
        await page.getByRole('checkbox', { name: c.checked, exact: true }).check();
      } else await page.getByTestId('customer-download').click();
      let downloads = 0; page.on('download', () => downloads++);
      await act(page, erase ? c.confirmErase : c.confirmDownload, 'one privacy command only', () => page.getByRole('button', { name: erase ? c.confirmErase : c.confirmDownload, exact: true }).click(), () => expect.poll(() => f.posts.length).toBe(1));
      if (fault.startsWith('read-')) {
        await expect(page.getByRole('button', { name: c.pending, exact: true })).toBeVisible();
        await parity(page, erase ? '45306' : '44801', erase ? '45347' : '44842');
        const reads = f.detailReads;
        await act(page, c.pending, 'read existing request without repeating POST', () => page.getByRole('button', { name: c.pending, exact: true }).click(), async () => {
          await expect.poll(() => f.detailReads, 'PARITY-PEOPLE: pending lookup actually reads server').toBeGreaterThan(reads);
          await expect(page.getByRole('button', { name: c.viewData, exact: true })).toBeVisible();
        });
        await parity(page, erase ? '45379' : '44874', erase ? '45424' : '44919');
        await page.getByRole('button', { name: c.viewData, exact: true }).click();
        await expect(page.getByTestId('customer-download')).toBeDisabled();
        await expect(page.getByTestId('customer-erase')).toBeDisabled();
        await parity(page, erase ? '45460' : '44955', erase ? '45516' : '45011');
        // Restore reads only (fixture preparation), then refresh; the uncertainty marker must remain fenced.
        await page.unrouteAll({ behavior: 'wait' }); await fixture(page); await page.reload();
        await expect(page.getByTestId('customer-download')).toBeDisabled();
        await expect(page.getByTestId('customer-erase')).toBeDisabled();
      } else {
        const title = fault === 'limit' ? p.limit : fault === 'blocked' ? p.blocked : fault === 'erase-success' ? p.erased : p.downloaded;
        await expect(page.getByRole('heading', { name: title, exact: true }), 'PARITY-PEOPLE: signed dedicated outcome').toBeVisible();
        await parity(page, fault === 'limit' ? '45105' : fault === 'blocked' ? '45563' : fault === 'erase-success' ? '45606' : '45058', fault === 'limit' ? '45131' : fault === 'blocked' ? '45589' : fault === 'erase-success' ? '45634' : '45086');
        if (fault !== 'none') expect(downloads).toBe(0);
        else await expect.poll(() => downloads).toBe(1);
        await act(page, p.back, 'same customer remains readable', () => page.getByRole('button', { name: p.back, exact: true }).last().click(), () => expect(page.getByTestId('customer-orders').locator('tbody tr')).toHaveCount(3));
        if (fault === 'erase-success') {
          await expect(page.getByTestId('customer-erased')).toBeVisible();
          await parity(page, '45653', '45704');
          await page.reload();
          await expect(page.getByTestId('customer-erased')).toBeVisible();
          await expect(page.getByTestId('customer-orders').locator('tbody tr')).toHaveCount(3);
        }
      }
      expect(f.posts).toHaveLength(1);
    });
  }
}

for (const width of [1440, 390]) {
  test(`PARITY withdrawn list is a server fact ${width}`, async ({ page }) => {
    await signed(page, width); await fixture(page, 'none', 'withdrawn'); await page.goto(mainURL('zh-TW'));
    await expect(page.getByTestId(`customer-row-${customer}`), 'PARITY-CONSENT-STATE: signed list distinguishes recorded withdrawal').toContainText(parityCopy['zh-TW'].marketing);
    await page.getByTestId(`customer-open-${customer}`).click();
    await expect(page.getByTestId('consent-marketing_messages')).toContainText('已撤回');
  });
  test(`PARITY privacy permission refusal ${width}`, async ({ page }) => {
    await signed(page, width); const f = await fixture(page, 'forbidden'); await page.goto(detailURL('zh-TW'));
    await page.getByTestId('customer-download').click();
    await page.getByRole('button', { name: copy['zh-TW'].confirmDownload, exact: true }).click();
    await expect(page.getByTestId('customer-download'), 'PARITY-PEOPLE: denied privacy commands stay disabled').toBeDisabled();
    await expect(page.getByTestId('customer-erase')).toBeDisabled();
    await expect(page.getByTestId('customer-orders').locator('tbody tr')).toHaveCount(3);
    await parity(page, '44564', '44654');
    expect(f.posts).toHaveLength(1);
  });
}
